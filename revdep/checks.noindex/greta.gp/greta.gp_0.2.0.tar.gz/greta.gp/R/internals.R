
# need some internal greta functions accessible
as.greta_array <- .internals$greta_array$as.greta_array
op <- .internals$nodes$constructors$op
fl <- .internals$utils$misc$fl
tf_float <- .internals$utils$misc$tf_float
tf_as_float <- .internals$tensors$tf_as_floa
check_tf_version <- .internals$checks$check_tf_version
