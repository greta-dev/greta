# project() errors as expected

    Can only project from greta arrays created with `greta.gp::gp`

