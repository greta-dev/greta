# kernels error on badly shaped inputs

    `X` must be a 2D greta array

---

    Number of columns of `X` and `X_prime` do not match
    i `X` has 1 columns
    i `X_prime` has 5 columns

# kernel constructors error on bad columns

    Columns has length: 2, but the kernel has dimension: 1

---

    Columns must be a vector of positive integers
    But we see columns as -1

# kernels error if combined with other things

    Can only combine a greta kernel with another greta kernel

---

    Can only combine a greta kernel with another greta kernel

---

    Can only combine a greta kernel with another greta kernel

---

    Can only combine a greta kernel with another greta kernel

# kernels print their own names

    bias kernel 

---

    linear kernel 

---

    radial basis kernel 

---

    exponential kernel 

---

    Matern 1/2 kernel 

---

    Matern 3/2 kernel 

---

    Matern 5/2 kernel 

---

    periodic kernel 

---

    additive kernel kernel 

---

    multiplicative kernel kernel 

