library(testthat)
library(tensorflow)
library(greta.gp)

test_check("greta.gp")
