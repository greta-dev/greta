#' The version 1.0.0 of this package was supported by the GAMBAS project funded by the French National Research Agency (ANR-18-CE02-0025).
#' This package was developed as part of the author activity at UR EFNO, INRAE, France.
#' @keywords internal
"_PACKAGE"
## usethis namespace: start usethis namespace: end
NULL
