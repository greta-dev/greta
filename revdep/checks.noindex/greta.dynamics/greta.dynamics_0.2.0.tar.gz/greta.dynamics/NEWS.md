# greta.dynamics 0.2.0

* Added a `NEWS.md` file to track changes to the package.
