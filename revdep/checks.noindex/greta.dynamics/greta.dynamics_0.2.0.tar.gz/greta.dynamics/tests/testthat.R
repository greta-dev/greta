library(testthat)
library(deSolve)
library(abind)
test_check("greta.dynamics")
